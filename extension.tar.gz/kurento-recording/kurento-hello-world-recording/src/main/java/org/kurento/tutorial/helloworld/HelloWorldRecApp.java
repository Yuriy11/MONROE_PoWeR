/*
 * (C) Copyright 2014-2016 Kurento (http://kurento.org/)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.kurento.tutorial.helloworld;

import org.kurento.client.KurentoClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

import java.util.Date;

/**
 * Hello World (WebRTC in loopback with recording) main class.
 *
 * @author Ivan Gracia (igracia@kurento.org)
 * @author Boni Garcia (bgarcia@gsyc.es)
 * @since 6.2.1
 */
@SpringBootApplication
@EnableWebSocket
public class HelloWorldRecApp implements WebSocketConfigurer {

  @Bean
  public HelloWorldRecHandler handler() {
    return new HelloWorldRecHandler();
  }

  @Bean
  public KurentoClient kurentoClient() {
    return KurentoClient.create();
  }

  @Override
  public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
    registry.addHandler(handler(), "/recording");
  }

  @Bean
  public UserRegistry registry() {
    return new UserRegistry();
  }

  public static void main(String[] args) throws Exception {
    new SpringApplication(HelloWorldRecApp.class).run(args);
//        KmsMonitor kmsMonitor = new KmsMonitor(System.getProperty("kms.ws.uri", DEFAULT_KMS_WS_URI));
//
//    while (true) {
//      // if (startTrigger == true) {
//      Date currentDate = new Date();
//      System.out.println(currentDate);
//      KmsStats kmsStats = kmsMonitor.updateStats();
//      outboundRtt = kmsStats.getWebRtcStats().getOutbound().getRtt();
//      outboundDeltaPlis = kmsStats.getWebRtcStats().getOutbound().getDeltaPlis();
//      outboundDeltaNecks = kmsStats.getWebRtcStats().getOutbound().getDeltaNacks();
//      outbondByteCount = kmsStats.getWebRtcStats().getOutbound().getByteCount();
//      outboundTargetBitrate = kmsStats.getWebRtcStats().getOutbound().getTargetBitrate();
//      inboundJitter = kmsStats.getWebRtcStats().getInbound().getJitter();
//      inboundFractionLost = kmsStats.getWebRtcStats().getInbound().getFractionLost();
//      inboundDeltaNeck = kmsStats.getWebRtcStats().getInbound().getDeltaNacks();
//      inboundDeltaPlis = kmsStats.getWebRtcStats().getInbound().getDeltaPlis();
//      inboundByteCount = kmsStats.getWebRtcStats().getInbound().getByteCount();
//      inboundPacketLostCount = kmsStats.getWebRtcStats().getInbound().getPacketLostCount();
//
//
//      if (k == 0) {
//        writeUsingBufferedWriter(outboundPath, "currentDate" + ";" + "RTT"
//                + ";delta Plis"
//                + ";delta Necks"
//                + ";byte Count"
//                + ";targetBitrate"
//                + ";", 1);
//
//        writeUsingBufferedWriter(inboundPath,  "currentDate" + ";" + "Jitter"
//                + ";Fraction Lost"
//                + ";delta Necks"
//                + ";delta Plis"
//                + ";byte Count"
//                + ";packet Lost"
//                + ";", 1);
//
//        k++;
//      } if(inboundByteCount>1) {
//        appendUsingBufferedWriter(outboundPath, currentDate + ";"  + outboundRtt+ ";"
//                +  outboundDeltaPlis + ";"
//                + outboundDeltaNecks+ ";"
//                +  outbondByteCount+ ";"
//                + outboundTargetBitrate
//                + ";", 1);
//        appendUsingBufferedWriter(inboundPath, currentDate + ";" + + inboundJitter+ ";"
//                + inboundFractionLost+ ";"
//                + inboundDeltaNeck+ ";"
//                +inboundDeltaPlis+ ";"
//                + inboundByteCount+ ";"
//                + inboundPacketLostCount
//                + ";", 1);
//      }


  }
}
